<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php // TODO HTML to display a formatted payment record ?>