<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class="note"><?php echo JText::_( "Payment Completed" ); ?></div>